import { Pool } from '@neondatabase/serverless';
import ws from 'ws';
import { neonConfig } from '@neondatabase/serverless';

neonConfig.webSocketConstructor = ws;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function seedData() {
  const client = await pool.connect();
  try {
    console.log('🌱 Iniciando seed de dados...\n');

    // Buscar IDs dos usuários
    const usersResult = await client.query('SELECT id, username FROM users ORDER BY username');
    const users = usersResult.rows;
    
    if (users.length === 0) {
      console.log('❌ Nenhum usuário encontrado. Execute o seed de usuários primeiro.');
      return;
    }

    const adminId = users.find(u => u.username === 'admin')?.id;
    const gerenteId = users.find(u => u.username === 'gerente')?.id;
    const funcionarioId = users.find(u => u.username === 'funcionario')?.id;

    console.log('✅ Usuários encontrados:', users.map(u => u.username).join(', '));

    // Verificar se já existem dados
    const clientsCount = await client.query('SELECT COUNT(*) FROM clients');
    if (parseInt(clientsCount.rows[0].count) > 0) {
      console.log('✅ Dados já existem no banco de dados\n');
      return;
    }

    // 1. Criar Clientes
    console.log('📋 Criando clientes...');
    const clientsResult = await client.query(`
      INSERT INTO clients (nome, email, telefone, empresa)
      VALUES 
        ('João Silva', 'joao@techcorp.com', '(11) 98765-4321', 'Tech Corp'),
        ('Maria Santos', 'maria@designstudio.com', '(21) 91234-5678', 'Design Studio'),
        ('Pedro Oliveira', 'pedro@startupx.com', '(31) 99876-5432', 'Startup X'),
        ('Ana Costa', 'ana@marketingpro.com', '(41) 98123-4567', 'Marketing Pro'),
        ('Carlos Mendes', 'carlos@ecommerce.com', '(51) 97654-3210', 'E-commerce Plus')
      RETURNING id
    `);
    const clientIds = clientsResult.rows.map(r => r.id);
    console.log(`✅ ${clientIds.length} clientes criados\n`);

    // 2. Criar Projetos
    console.log('🎨 Criando projetos...');
    const projectsResult = await client.query(`
      INSERT INTO projects (titulo, descricao, valor, status, data_inicio, prazo, cliente_id, responsavel_id)
      VALUES 
        ('Website Institucional', 'Desenvolvimento de site institucional moderno e responsivo', 15000.00, 'em_andamento', NOW() - INTERVAL '30 days', NOW() + INTERVAL '15 days', $1, $2),
        ('Aplicativo Mobile', 'App iOS e Android para gestão de vendas', 45000.00, 'em_andamento', NOW() - INTERVAL '45 days', NOW() + INTERVAL '30 days', $3, $4),
        ('Sistema de E-commerce', 'Plataforma completa de vendas online', 80000.00, 'em_andamento', NOW() - INTERVAL '60 days', NOW() + INTERVAL '60 days', $5, $6),
        ('Identidade Visual', 'Criação de marca e materiais gráficos', 8500.00, 'concluido', NOW() - INTERVAL '90 days', NOW() - INTERVAL '10 days', $7, $8),
        ('Campanha de Marketing', 'Estratégia digital e criação de conteúdo', 12000.00, 'nao_iniciado', NOW(), NOW() + INTERVAL '45 days', $9, $10),
        ('Dashboard Analytics', 'Sistema de análise de dados em tempo real', 35000.00, 'em_andamento', NOW() - INTERVAL '20 days', NOW() + INTERVAL '40 days', $11, $12)
      RETURNING id
    `, [
      clientIds[0], adminId,
      clientIds[1], gerenteId, 
      clientIds[2], adminId,
      clientIds[3], gerenteId,
      clientIds[4], funcionarioId,
      clientIds[0], adminId
    ]);
    const projectIds = projectsResult.rows.map(r => r.id);
    console.log(`✅ ${projectIds.length} projetos criados\n`);

    // 3. Criar Tarefas
    console.log('✅ Criando tarefas...');
    await client.query(`
      INSERT INTO tasks (titulo, descricao, status, assigned_to_id, created_by_id, project_id, data_vencimento)
      VALUES 
        ('Design da homepage', 'Criar layout responsivo da página inicial', 'concluida', $1, $2, $3, NOW() + INTERVAL '3 days'),
        ('Implementar autenticação', 'Sistema de login e registro de usuários', 'pendente', $4, $5, $6, NOW() + INTERVAL '5 days'),
        ('Criar API REST', 'Desenvolver endpoints do backend', 'pendente', $7, $8, $9, NOW() + INTERVAL '7 days'),
        ('Testes de integração', 'Implementar testes automatizados', 'pendente', $10, $11, $12, NOW() + INTERVAL '10 days'),
        ('Deploy em produção', 'Configurar CI/CD e fazer deploy', 'concluida', $13, $14, $15, NOW() - INTERVAL '2 days'),
        ('Otimização de performance', 'Melhorar velocidade de carregamento', 'pendente', $16, $17, $18, NOW() + INTERVAL '4 days'),
        ('Documentação técnica', 'Criar guia de uso do sistema', 'concluida', $19, $20, $21, NOW() - INTERVAL '5 days'),
        ('Integração com gateway', 'Conectar sistema de pagamento', 'pendente', $22, $23, $24, NOW() + INTERVAL '8 days')
    `, [
      funcionarioId, adminId, projectIds[0],
      gerenteId, adminId, projectIds[1],
      adminId, gerenteId, projectIds[2],
      funcionarioId, gerenteId, projectIds[3],
      adminId, gerenteId, projectIds[3],
      gerenteId, adminId, projectIds[4],
      funcionarioId, adminId, projectIds[5],
      adminId, gerenteId, projectIds[2]
    ]);
    console.log('✅ 8 tarefas criadas\n');

    // 4. Criar Transações Financeiras
    console.log('💰 Criando transações financeiras...');
    await client.query(`
      INSERT INTO transactions (tipo, valor, descricao, categoria, project_id, data, created_by_id)
      VALUES 
        ('receita', 15000.00, 'Pagamento Website Institucional', 'Serviços', $1, NOW() - INTERVAL '10 days', $2),
        ('receita', 22500.00, 'Primeira parcela App Mobile', 'Serviços', $3, NOW() - INTERVAL '20 days', $4),
        ('receita', 40000.00, 'Adiantamento E-commerce', 'Serviços', $5, NOW() - INTERVAL '30 days', $6),
        ('despesa', 3500.00, 'Licenças de software', 'Software', NULL, NOW() - INTERVAL '15 days', $7),
        ('despesa', 2800.00, 'Servidor cloud mensal', 'Infraestrutura', NULL, NOW() - INTERVAL '5 days', $8),
        ('receita', 8500.00, 'Projeto Identidade Visual', 'Serviços', $9, NOW() - INTERVAL '25 days', $10),
        ('despesa', 1200.00, 'Freelancer designer', 'Recursos Humanos', $11, NOW() - INTERVAL '12 days', $12),
        ('receita', 12000.00, 'Campanha de Marketing', 'Serviços', $13, NOW() - INTERVAL '8 days', $14),
        ('despesa', 850.00, 'Adobe Creative Cloud', 'Software', NULL, NOW() - INTERVAL '3 days', $15),
        ('receita', 17500.00, 'Segunda parcela Dashboard', 'Serviços', $16, NOW() - INTERVAL '6 days', $17)
    `, [
      projectIds[0], adminId,
      projectIds[1], gerenteId,
      projectIds[2], adminId,
      adminId,
      gerenteId,
      projectIds[3], adminId,
      projectIds[3], gerenteId,
      projectIds[4], adminId,
      adminId,
      projectIds[5], gerenteId
    ]);
    console.log('✅ 10 transações criadas\n');

    // 5. Criar Avisos
    console.log('📢 Criando avisos...');
    await client.query(`
      INSERT INTO announcements (titulo, mensagem, target_role, created_by_id)
      VALUES 
        ('Nova atualização do sistema', 'Sistema foi atualizado com novas funcionalidades de relatórios', NULL, $1),
        ('Reunião semanal', 'Reunião de alinhamento toda segunda-feira às 10h', 'gerente', $2),
        ('Prazo importante', 'Lembrete: entrega do projeto E-commerce em 60 dias', 'admin', $3),
        ('Novo cliente', 'Bem-vindo ao novo cliente Marketing Pro!', NULL, $4),
        ('Manutenção programada', 'Servidor em manutenção no domingo das 2h às 4h', 'admin', $5)
    `, [adminId, gerenteId, adminId, gerenteId, adminId]);
    console.log('✅ 5 avisos criados\n');

    // 6. Criar Timesheet
    console.log('⏰ Criando registros de timesheet...');
    await client.query(`
      INSERT INTO timesheet_entries (user_id, task_id, project_id, descricao, horas_trabalhadas, data)
      SELECT 
        u.id,
        t.id,
        t.project_id,
        'Trabalho em: ' || t.titulo,
        (RANDOM() * 6 + 2)::numeric(5,2),
        NOW() - (RANDOM() * INTERVAL '30 days')
      FROM users u
      CROSS JOIN tasks t
      WHERE RANDOM() < 0.4
      LIMIT 20
    `);
    console.log('✅ Registros de timesheet criados\n');

    // 7. Criar Mensagens de Chat
    console.log('💬 Criando mensagens de chat...');
    await client.query(`
      INSERT INTO chat_messages (sender_id, mensagem)
      VALUES 
        ($1, 'Bom dia equipe! Como estão os projetos hoje?'),
        ($2, 'Tudo certo por aqui! Finalizei a homepage do site institucional.'),
        ($3, 'Ótimo trabalho! Precisamos revisar o sistema de autenticação.'),
        ($4, 'Já estou trabalhando nisso. Deve ficar pronto até amanhã.'),
        ($5, 'Perfeito! Vamos agendar uma reunião para sexta-feira então.')
    `, [adminId, funcionarioId, gerenteId, adminId, gerenteId]);
    console.log('✅ Mensagens de chat criadas\n');

    console.log('\n🎉 Seed de dados concluído com sucesso!\n');
    console.log('📊 Resumo:');
    console.log('   - 5 Clientes');
    console.log('   - 6 Projetos');
    console.log('   - 8 Tarefas');
    console.log('   - 10 Transações');
    console.log('   - 5 Avisos');
    console.log('   - ~20 Registros de Timesheet');
    console.log('   - 5 Mensagens de Chat\n');

  } catch (error) {
    console.error('❌ Erro ao criar dados:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

seedData();
