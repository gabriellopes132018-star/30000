import express from "express";
import { createServer } from "http";
import { WebSocketServer } from "ws";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import authRoutes from "./routes/auth";
import clientsRoutes from "./routes/clients";
import projectsRoutes from "./routes/projects";
import tasksRoutes from "./routes/tasks";
import transactionsRoutes from "./routes/transactions";
import timesheetRoutes from "./routes/timesheet";
import announcementsRoutes from "./routes/announcements";
import usersRoutes from "./routes/users";
import dashboardRoutes from "./routes/dashboard";
import userManagementRoutes from "./routes/user-management";

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }
  next();
});

app.use("/api/auth", authRoutes);
app.use("/api/clients", clientsRoutes);
app.use("/api/projects", projectsRoutes);
app.use("/api/tasks", tasksRoutes);
app.use("/api/transactions", transactionsRoutes);
app.use("/api/timesheet", timesheetRoutes);
app.use("/api/announcements", announcementsRoutes);
app.use("/api/users", usersRoutes);
app.use("/api/users/manage", userManagementRoutes);
app.use("/api/dashboard", dashboardRoutes);

const clients = new Map();

wss.on("connection", (ws, req) => {
  console.log("New WebSocket connection");
  
  let userId: string | null = null;

  ws.on("message", (data) => {
    try {
      const message = JSON.parse(data.toString());
      
      if (message.type === "register") {
        userId = message.userId;
        clients.set(userId, ws);
        console.log(`User ${userId} registered`);
      } else if (message.type === "message") {
        const targetClient = clients.get(message.receiverId);
        if (targetClient && targetClient.readyState === 1) {
          targetClient.send(JSON.stringify({
            type: "message",
            senderId: message.senderId,
            senderName: message.senderName,
            message: message.message,
            createdAt: new Date().toISOString(),
          }));
        }
        
        if (userId) {
          const senderClient = clients.get(userId);
          if (senderClient && senderClient.readyState === 1) {
            senderClient.send(JSON.stringify({
              type: "message",
              senderId: message.senderId,
              receiverId: message.receiverId,
              message: message.message,
              createdAt: new Date().toISOString(),
            }));
          }
        }
      }
    } catch (error) {
      console.error("WebSocket message error:", error);
    }
  });

  ws.on("close", () => {
    if (userId) {
      clients.delete(userId);
      console.log(`User ${userId} disconnected`);
    }
  });

  ws.on("error", (error) => {
    console.error("WebSocket error:", error);
  });
});

if (process.env.NODE_ENV === "production") {
  const distPath = path.join(__dirname, "../dist/public");
  app.use(express.static(distPath));
  
  app.get("*", (req, res) => {
    res.sendFile(path.join(distPath, "index.html"));
  });
}

server.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📡 WebSocket server running on ws://localhost:${PORT}/ws`);
});
