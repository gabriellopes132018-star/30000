import { Router } from "express";
import { db } from "../shared/db";
import { transactions, projects } from "../shared/schema";
import { eq } from "drizzle-orm";
import { authenticateToken, AuthRequest } from "../middleware/auth";

const router = Router();

router.use(authenticateToken);

router.get("/", async (req: AuthRequest, res) => {
  try {
    const allTransactions = await db
      .select({
        id: transactions.id,
        tipo: transactions.tipo,
        descricao: transactions.descricao,
        valor: transactions.valor,
        categoria: transactions.categoria,
        data: transactions.data,
        projetoId: transactions.projetoId,
        status: transactions.status,
        createdAt: transactions.createdAt,
        projetoTitulo: projects.titulo,
      })
      .from(transactions)
      .leftJoin(projects, eq(transactions.projetoId, projects.id));
    res.json(allTransactions);
  } catch (error) {
    console.error("Error fetching transactions:", error);
    res.status(500).json({ message: "Erro ao buscar transações" });
  }
});

router.post("/", async (req: AuthRequest, res) => {
  try {
    const [newTransaction] = await db.insert(transactions).values(req.body).returning();
    res.json(newTransaction);
  } catch (error) {
    console.error("Error creating transaction:", error);
    res.status(500).json({ message: "Erro ao criar transação" });
  }
});

router.put("/:id", async (req: AuthRequest, res) => {
  try {
    const [updated] = await db
      .update(transactions)
      .set(req.body)
      .where(eq(transactions.id, parseInt(req.params.id)))
      .returning();
    res.json(updated);
  } catch (error) {
    console.error("Error updating transaction:", error);
    res.status(500).json({ message: "Erro ao atualizar transação" });
  }
});

router.delete("/:id", async (req: AuthRequest, res) => {
  try {
    await db.delete(transactions).where(eq(transactions.id, parseInt(req.params.id)));
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting transaction:", error);
    res.status(500).json({ message: "Erro ao deletar transação" });
  }
});

export default router;
