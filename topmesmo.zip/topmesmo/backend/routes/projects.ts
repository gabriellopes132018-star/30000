import { Router } from "express";
import { db } from "../shared/db";
import { projects, clients, users } from "../shared/schema";
import { eq } from "drizzle-orm";
import { authenticateToken, AuthRequest } from "../middleware/auth";
import multer from "multer";

const router = Router();
const upload = multer({ dest: "uploads/" });

router.use(authenticateToken);

router.get("/", async (req: AuthRequest, res) => {
  try {
    const allProjects = await db
      .select({
        id: projects.id,
        titulo: projects.titulo,
        descricao: projects.descricao,
        valor: projects.valor,
        status: projects.status,
        dataInicio: projects.dataInicio,
        prazo: projects.prazo,
        clienteId: projects.clienteId,
        responsavelId: projects.responsavelId,
        arquivos: projects.arquivos,
        createdAt: projects.createdAt,
        clienteNome: clients.nome,
        responsavelNome: users.nome,
      })
      .from(projects)
      .leftJoin(clients, eq(projects.clienteId, clients.id))
      .leftJoin(users, eq(projects.responsavelId, users.id));
    res.json(allProjects);
  } catch (error) {
    console.error("Error fetching projects:", error);
    res.status(500).json({ message: "Erro ao buscar projetos" });
  }
});

router.post("/", async (req: AuthRequest, res) => {
  try {
    const [newProject] = await db.insert(projects).values(req.body).returning();
    res.json(newProject);
  } catch (error) {
    console.error("Error creating project:", error);
    res.status(500).json({ message: "Erro ao criar projeto" });
  }
});

router.put("/:id", async (req: AuthRequest, res) => {
  try {
    const [updated] = await db
      .update(projects)
      .set(req.body)
      .where(eq(projects.id, parseInt(req.params.id)))
      .returning();
    res.json(updated);
  } catch (error) {
    console.error("Error updating project:", error);
    res.status(500).json({ message: "Erro ao atualizar projeto" });
  }
});

router.post("/:id/upload", upload.array("files"), async (req: AuthRequest, res) => {
  try {
    res.json({ success: true, files: req.files });
  } catch (error) {
    console.error("Error uploading files:", error);
    res.status(500).json({ message: "Erro ao fazer upload" });
  }
});

router.delete("/:id", async (req: AuthRequest, res) => {
  try {
    await db.delete(projects).where(eq(projects.id, parseInt(req.params.id)));
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting project:", error);
    res.status(500).json({ message: "Erro ao deletar projeto" });
  }
});

export default router;
