import { Router } from "express";
import { db } from "../shared/db";
import { users } from "../shared/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";

router.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;

    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username))
      .limit(1);

    if (!user) {
      return res.status(401).json({ message: "Usuário não encontrado" });
    }

    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) {
      return res.status(401).json({ message: "Senha incorreta" });
    }

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    const { password: _, ...userWithoutPassword } = user;

    res.json({
      token,
      user: userWithoutPassword,
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Erro ao fazer login" });
  }
});

router.post("/forgot-password", async (req, res) => {
  try {
    const { email } = req.body;

    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    if (!user) {
      return res.json({ success: true, message: "Se o email existir, você receberá as instruções" });
    }

    res.json({ success: true, message: "Email de recuperação enviado" });
  } catch (error) {
    console.error("Forgot password error:", error);
    res.status(500).json({ message: "Erro ao processar solicitação" });
  }
});

router.post("/reset-password", async (req, res) => {
  try {
    const { token, newPassword } = req.body;

    res.json({ success: true, message: "Senha redefinida com sucesso" });
  } catch (error) {
    console.error("Reset password error:", error);
    res.status(500).json({ message: "Erro ao redefinir senha" });
  }
});

export default router;
