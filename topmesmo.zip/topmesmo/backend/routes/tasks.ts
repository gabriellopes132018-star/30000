import { Router } from "express";
import { db } from "../shared/db";
import { tasks, projects, users } from "../shared/schema";
import { eq } from "drizzle-orm";
import { authenticateToken, AuthRequest } from "../middleware/auth";

const router = Router();

router.use(authenticateToken);

router.get("/", async (req: AuthRequest, res) => {
  try {
    const allTasks = await db
      .select({
        id: tasks.id,
        titulo: tasks.titulo,
        descricao: tasks.descricao,
        status: tasks.status,
        prioridade: tasks.prioridade,
        prazo: tasks.prazo,
        projetoId: tasks.projetoId,
        responsavelId: tasks.responsavelId,
        createdAt: tasks.createdAt,
        updatedAt: tasks.updatedAt,
        projetoTitulo: projects.titulo,
        responsavelNome: users.nome,
      })
      .from(tasks)
      .leftJoin(projects, eq(tasks.projetoId, projects.id))
      .leftJoin(users, eq(tasks.responsavelId, users.id));
    res.json(allTasks);
  } catch (error) {
    console.error("Error fetching tasks:", error);
    res.status(500).json({ message: "Erro ao buscar tarefas" });
  }
});

router.post("/", async (req: AuthRequest, res) => {
  try {
    const [newTask] = await db.insert(tasks).values(req.body).returning();
    res.json(newTask);
  } catch (error) {
    console.error("Error creating task:", error);
    res.status(500).json({ message: "Erro ao criar tarefa" });
  }
});

router.put("/:id", async (req: AuthRequest, res) => {
  try {
    const [updated] = await db
      .update(tasks)
      .set({ ...req.body, updatedAt: new Date() })
      .where(eq(tasks.id, parseInt(req.params.id)))
      .returning();
    res.json(updated);
  } catch (error) {
    console.error("Error updating task:", error);
    res.status(500).json({ message: "Erro ao atualizar tarefa" });
  }
});

router.put("/:id/status", async (req: AuthRequest, res) => {
  try {
    const [updated] = await db
      .update(tasks)
      .set({ status: req.body.status, updatedAt: new Date() })
      .where(eq(tasks.id, parseInt(req.params.id)))
      .returning();
    res.json(updated);
  } catch (error) {
    console.error("Error updating task status:", error);
    res.status(500).json({ message: "Erro ao atualizar status" });
  }
});

router.delete("/:id", async (req: AuthRequest, res) => {
  try {
    await db.delete(tasks).where(eq(tasks.id, parseInt(req.params.id)));
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting task:", error);
    res.status(500).json({ message: "Erro ao deletar tarefa" });
  }
});

export default router;
