import { Router } from "express";
import { db } from "../shared/db";
import { clients } from "../shared/schema";
import { eq } from "drizzle-orm";
import { authenticateToken, AuthRequest } from "../middleware/auth";

const router = Router();

router.use(authenticateToken);

router.get("/", async (req: AuthRequest, res) => {
  try {
    const allClients = await db.select().from(clients);
    res.json(allClients);
  } catch (error) {
    console.error("Error fetching clients:", error);
    res.status(500).json({ message: "Erro ao buscar clientes" });
  }
});

router.post("/", async (req: AuthRequest, res) => {
  try {
    const [newClient] = await db.insert(clients).values(req.body).returning();
    res.json(newClient);
  } catch (error) {
    console.error("Error creating client:", error);
    res.status(500).json({ message: "Erro ao criar cliente" });
  }
});

router.put("/:id", async (req: AuthRequest, res) => {
  try {
    const [updated] = await db
      .update(clients)
      .set(req.body)
      .where(eq(clients.id, parseInt(req.params.id)))
      .returning();
    res.json(updated);
  } catch (error) {
    console.error("Error updating client:", error);
    res.status(500).json({ message: "Erro ao atualizar cliente" });
  }
});

router.delete("/:id", async (req: AuthRequest, res) => {
  try {
    await db.delete(clients).where(eq(clients.id, parseInt(req.params.id)));
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting client:", error);
    res.status(500).json({ message: "Erro ao deletar cliente" });
  }
});

export default router;
