import { Router } from "express";
import { db } from "../shared/db";
import { users } from "../shared/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcrypt";
import { authenticateToken, AuthRequest } from "../middleware/auth";

const router = Router();

router.use(authenticateToken);

router.get("/", async (req: AuthRequest, res) => {
  try {
    if (req.user?.role !== "admin" && req.user?.role !== "gerente") {
      return res.status(403).json({ message: "Acesso negado" });
    }

    let allUsers;
    if (req.user.role === "admin") {
      allUsers = await db.select({
        id: users.id,
        username: users.username,
        nome: users.nome,
        email: users.email,
        role: users.role,
        createdAt: users.createdAt,
      }).from(users);
    } else {
      allUsers = await db.select({
        id: users.id,
        username: users.username,
        nome: users.nome,
        email: users.email,
        role: users.role,
        createdAt: users.createdAt,
      }).from(users).where(eq(users.role, "funcionario"));
    }

    res.json(allUsers);
  } catch (error) {
    console.error("Error fetching users:", error);
    res.status(500).json({ message: "Erro ao buscar usuários" });
  }
});

router.post("/", async (req: AuthRequest, res) => {
  try {
    if (req.user?.role !== "admin" && req.user?.role !== "gerente") {
      return res.status(403).json({ message: "Acesso negado" });
    }

    const { username, password, nome, email, role } = req.body;

    if (req.user.role === "gerente" && role !== "funcionario") {
      return res.status(403).json({ message: "Gerentes só podem criar funcionários" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const [newUser] = await db
      .insert(users)
      .values({
        username,
        password: hashedPassword,
        nome,
        email,
        role,
      })
      .returning();

    const { password: _, ...userWithoutPassword } = newUser;
    res.json(userWithoutPassword);
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ message: "Erro ao criar usuário" });
  }
});

router.put("/:id", async (req: AuthRequest, res) => {
  try {
    if (req.user?.role !== "admin" && req.user?.role !== "gerente") {
      return res.status(403).json({ message: "Acesso negado" });
    }

    const userId = parseInt(req.params.id);
    const { username, password, nome, email, role } = req.body;

    const [targetUser] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (!targetUser) {
      return res.status(404).json({ message: "Usuário não encontrado" });
    }

    if (req.user.role === "gerente" && targetUser.role !== "funcionario") {
      return res.status(403).json({ message: "Gerentes só podem editar funcionários" });
    }

    if (req.user.role === "gerente" && role !== "funcionario") {
      return res.status(403).json({ message: "Gerentes não podem alterar funções" });
    }

    const updateData: any = { username, nome, email, role };
    
    if (password) {
      updateData.password = await bcrypt.hash(password, 10);
    }

    const [updated] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, userId))
      .returning();

    const { password: _, ...userWithoutPassword } = updated;
    res.json(userWithoutPassword);
  } catch (error) {
    console.error("Error updating user:", error);
    res.status(500).json({ message: "Erro ao atualizar usuário" });
  }
});

router.delete("/:id", async (req: AuthRequest, res) => {
  try {
    if (req.user?.role !== "admin" && req.user?.role !== "gerente") {
      return res.status(403).json({ message: "Acesso negado" });
    }

    const userId = parseInt(req.params.id);

    const [targetUser] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (!targetUser) {
      return res.status(404).json({ message: "Usuário não encontrado" });
    }

    if (req.user.role === "gerente" && targetUser.role !== "funcionario") {
      return res.status(403).json({ message: "Gerentes só podem excluir funcionários" });
    }

    if (targetUser.id === req.user.id) {
      return res.status(400).json({ message: "Você não pode excluir sua própria conta" });
    }

    await db.delete(users).where(eq(users.id, userId));
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting user:", error);
    res.status(500).json({ message: "Erro ao excluir usuário" });
  }
});

export default router;
