import { Router } from "express";
import { db } from "../shared/db";
import { projects, tasks, transactions, clients } from "../shared/schema";
import { eq, sql } from "drizzle-orm";
import { authenticateToken, AuthRequest } from "../middleware/auth";

const router = Router();

router.use(authenticateToken);

router.get("/stats", async (req: AuthRequest, res) => {
  try {
    const [projectCount] = await db.select({ count: sql<number>`count(*)` }).from(projects);
    const [taskCount] = await db.select({ count: sql<number>`count(*)` }).from(tasks);
    const [clientCount] = await db.select({ count: sql<number>`count(*)` }).from(clients);
    
    const [revenueResult] = await db
      .select({ 
        total: sql<string>`COALESCE(SUM(${transactions.valor}), 0)` 
      })
      .from(transactions)
      .where(eq(transactions.tipo, "receita"));

    const [expenseResult] = await db
      .select({ 
        total: sql<string>`COALESCE(SUM(${transactions.valor}), 0)` 
      })
      .from(transactions)
      .where(eq(transactions.tipo, "despesa"));

    const recentProjects = await db
      .select()
      .from(projects)
      .orderBy(projects.createdAt)
      .limit(5);

    const recentTasks = await db
      .select()
      .from(tasks)
      .orderBy(tasks.createdAt)
      .limit(5);

    res.json({
      projects: {
        total: projectCount.count || 0,
        active: recentProjects.filter(p => p.status === "em_andamento").length,
        completed: recentProjects.filter(p => p.status === "concluido").length,
      },
      tasks: {
        total: taskCount.count || 0,
        pending: recentTasks.filter(t => t.status === "pendente").length,
        inProgress: recentTasks.filter(t => t.status === "em_andamento").length,
        completed: recentTasks.filter(t => t.status === "concluida").length,
      },
      clients: {
        total: clientCount.count || 0,
      },
      financial: {
        revenue: parseFloat(revenueResult?.total || "0"),
        expenses: parseFloat(expenseResult?.total || "0"),
        balance: parseFloat(revenueResult?.total || "0") - parseFloat(expenseResult?.total || "0"),
      },
      recentProjects,
      recentTasks,
    });
  } catch (error) {
    console.error("Error fetching dashboard stats:", error);
    res.status(500).json({ message: "Erro ao buscar estatísticas" });
  }
});

export default router;
