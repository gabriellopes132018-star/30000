import { Router } from "express";
import { db } from "../shared/db";
import { timesheet, users, projects, tasks } from "../shared/schema";
import { eq } from "drizzle-orm";
import { authenticateToken, AuthRequest } from "../middleware/auth";

const router = Router();

router.use(authenticateToken);

router.get("/", async (req: AuthRequest, res) => {
  try {
    const allTimesheet = await db
      .select({
        id: timesheet.id,
        usuarioId: timesheet.usuarioId,
        projetoId: timesheet.projetoId,
        tarefaId: timesheet.tarefaId,
        descricao: timesheet.descricao,
        horas: timesheet.horas,
        data: timesheet.data,
        createdAt: timesheet.createdAt,
        usuarioNome: users.nome,
        projetoTitulo: projects.titulo,
        tarefaTitulo: tasks.titulo,
      })
      .from(timesheet)
      .leftJoin(users, eq(timesheet.usuarioId, users.id))
      .leftJoin(projects, eq(timesheet.projetoId, projects.id))
      .leftJoin(tasks, eq(timesheet.tarefaId, tasks.id));
    res.json(allTimesheet);
  } catch (error) {
    console.error("Error fetching timesheet:", error);
    res.status(500).json({ message: "Erro ao buscar timesheet" });
  }
});

router.post("/", async (req: AuthRequest, res) => {
  try {
    const [newEntry] = await db.insert(timesheet).values(req.body).returning();
    res.json(newEntry);
  } catch (error) {
    console.error("Error creating timesheet entry:", error);
    res.status(500).json({ message: "Erro ao criar entrada" });
  }
});

router.put("/:id", async (req: AuthRequest, res) => {
  try {
    const [updated] = await db
      .update(timesheet)
      .set(req.body)
      .where(eq(timesheet.id, parseInt(req.params.id)))
      .returning();
    res.json(updated);
  } catch (error) {
    console.error("Error updating timesheet entry:", error);
    res.status(500).json({ message: "Erro ao atualizar entrada" });
  }
});

router.delete("/:id", async (req: AuthRequest, res) => {
  try {
    await db.delete(timesheet).where(eq(timesheet.id, parseInt(req.params.id)));
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting timesheet entry:", error);
    res.status(500).json({ message: "Erro ao deletar entrada" });
  }
});

export default router;
