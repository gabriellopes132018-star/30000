import { Router } from "express";
import { db } from "../shared/db";
import { announcements, users } from "../shared/schema";
import { eq } from "drizzle-orm";
import { authenticateToken, AuthRequest } from "../middleware/auth";

const router = Router();

router.use(authenticateToken);

router.get("/", async (req: AuthRequest, res) => {
  try {
    const allAnnouncements = await db
      .select({
        id: announcements.id,
        titulo: announcements.titulo,
        conteudo: announcements.conteudo,
        tipo: announcements.tipo,
        autorId: announcements.autorId,
        publicado: announcements.publicado,
        createdAt: announcements.createdAt,
        autorNome: users.nome,
      })
      .from(announcements)
      .leftJoin(users, eq(announcements.autorId, users.id));
    res.json(allAnnouncements);
  } catch (error) {
    console.error("Error fetching announcements:", error);
    res.status(500).json({ message: "Erro ao buscar avisos" });
  }
});

router.post("/", async (req: AuthRequest, res) => {
  try {
    const [newAnnouncement] = await db
      .insert(announcements)
      .values({ ...req.body, autorId: req.user!.id })
      .returning();
    res.json(newAnnouncement);
  } catch (error) {
    console.error("Error creating announcement:", error);
    res.status(500).json({ message: "Erro ao criar aviso" });
  }
});

router.put("/:id", async (req: AuthRequest, res) => {
  try {
    const [updated] = await db
      .update(announcements)
      .set(req.body)
      .where(eq(announcements.id, parseInt(req.params.id)))
      .returning();
    res.json(updated);
  } catch (error) {
    console.error("Error updating announcement:", error);
    res.status(500).json({ message: "Erro ao atualizar aviso" });
  }
});

router.delete("/:id", async (req: AuthRequest, res) => {
  try {
    await db.delete(announcements).where(eq(announcements.id, parseInt(req.params.id)));
    res.json({ success: true });
  } catch (error) {
    console.error("Error deleting announcement:", error);
    res.status(500).json({ message: "Erro ao deletar aviso" });
  }
});

export default router;
