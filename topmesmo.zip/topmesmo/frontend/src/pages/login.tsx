import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Sparkles, Lock, User, ArrowRight, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erro ao fazer login");
      }

      const data = await response.json();
      login(data.user, data.token);
      
      toast({
        title: "✨ Login realizado!",
        description: `Bem-vindo de volta, ${data.user.nome}!`,
      });
      
      setTimeout(() => {
        setLocation("/dashboard");
      }, 100);
    } catch (error) {
      toast({
        title: "Erro no login",
        description: error instanceof Error ? error.message : "Credenciais inválidas",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-3 sm:p-4">
      {/* Background gradiente premium escuro */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900">
        {/* Grid pattern overlay animado */}
        <div 
          className="absolute inset-0 opacity-10 animate-pulse"
          style={{
            backgroundImage: `linear-gradient(rgba(139, 92, 246, 0.15) 1.5px, transparent 1.5px), linear-gradient(90deg, rgba(139, 92, 246, 0.15) 1.5px, transparent 1.5px)`,
            backgroundSize: '60px 60px',
            animation: 'grid-move 20s linear infinite'
          }}
        />
      </div>

      {/* Animated gradient orbs de fundo */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -left-40 w-[300px] sm:w-[500px] h-[300px] sm:h-[500px] bg-purple-600/30 rounded-full mix-blend-multiply filter blur-[80px] sm:blur-[100px] animate-blob" />
        <div className="absolute -top-40 -right-40 w-[300px] sm:w-[500px] h-[300px] sm:h-[500px] bg-blue-600/30 rounded-full mix-blend-multiply filter blur-[80px] sm:blur-[100px] animate-blob delay-1000" />
        <div className="absolute -bottom-40 left-1/2 w-[300px] sm:w-[500px] h-[300px] sm:h-[500px] bg-pink-600/30 rounded-full mix-blend-multiply filter blur-[80px] sm:blur-[100px] animate-blob delay-2000" />
      </div>

      {/* CARD PRINCIPAL COM TUDO DENTRO - COMPACTO E RESPONSIVO */}
      <Card className="w-full max-w-[95%] sm:max-w-md relative z-10 border-0 shadow-2xl bg-white/[0.02] backdrop-blur-3xl overflow-hidden rounded-3xl animate-scale-in">
        {/* Card glow effect animado */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-blue-500/10 to-pink-500/10 animate-gradient" />
        
        {/* Borda gradiente animada */}
        <div className="absolute inset-0 rounded-3xl p-[2px] bg-gradient-to-br from-purple-500/70 via-blue-500/70 to-pink-500/70 animate-gradient bg-[length:200%_auto]">
          <div className="h-full w-full rounded-3xl bg-slate-900/95 backdrop-blur-3xl" />
        </div>

        <CardContent className="relative z-10 p-5 sm:p-6 md:p-8">
          {/* Logo EXTRAORDINÁRIA DENTRO DO CARD */}
          <div className="flex items-center justify-center mb-4 sm:mb-5">
            <div className="relative group cursor-pointer">
              {/* Aura ultra sofisticada com múltiplas camadas */}
              <div className="absolute -inset-10 sm:-inset-12 bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 rounded-full opacity-40 blur-2xl sm:blur-3xl group-hover:opacity-70 transition-all duration-1000 animate-pulse" 
                   style={{ animationDuration: '4s' }} />
              <div className="absolute -inset-6 sm:-inset-8 bg-gradient-to-br from-purple-600 via-pink-600 to-blue-600 rounded-full opacity-50 blur-xl sm:blur-2xl group-hover:opacity-80 transition-all duration-700 animate-pulse delay-1000" 
                   style={{ animationDuration: '3s' }} />
              
              {/* Logo Lopes Designer - Imagem real */}
              <div className="relative flex items-center justify-center transform group-hover:scale-110 transition-all duration-500">
                <img 
                  src="/logo-lopes.png" 
                  alt="Lopes Designer" 
                  className="h-20 w-auto sm:h-24 object-contain drop-shadow-2xl filter brightness-110 contrast-110"
                />
              </div>
            </div>
          </div>

          {/* Subtítulo ultra sofisticado */}
          <div className="text-center mb-4 sm:mb-5 space-y-1">
            <p className="text-slate-200 text-sm sm:text-base font-semibold tracking-wide">
              Sistema de Gestão Profissional
            </p>
            <div className="flex items-center justify-center gap-2 mt-2">
              <div className="h-px w-8 bg-gradient-to-r from-transparent via-purple-500 to-transparent"></div>
              <span className="text-slate-400 text-xs uppercase tracking-widest font-medium">2025</span>
              <div className="h-px w-8 bg-gradient-to-r from-transparent via-blue-500 to-transparent"></div>
            </div>
          </div>

          {/* Divider decorativo fino */}
          <div className="relative mb-4 sm:mb-5">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-700/50"></div>
            </div>
            <div className="relative flex justify-center text-[10px] sm:text-xs uppercase">
              <span className="bg-slate-900 px-3 text-slate-400 font-semibold tracking-wider">Acesso</span>
            </div>
          </div>

          {/* Formulário de Login compacto */}
          <form onSubmit={handleSubmit} className="space-y-3 sm:space-y-4">
            {/* Username field */}
            <div className="space-y-1.5">
              <Label htmlFor="username" className="text-slate-200 font-medium text-xs">
                Usuário
              </Label>
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl opacity-0 group-hover:opacity-30 group-focus-within:opacity-40 blur-lg transition-all duration-500" />
                <div className="relative flex items-center">
                  <User className="absolute left-3 h-4 w-4 text-slate-500 group-hover:text-purple-400 group-focus-within:text-purple-400 transition-all duration-300" />
                  <Input
                    id="username"
                    type="text"
                    placeholder="Digite seu usuário"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    required
                    className="pl-10 pr-3 h-11 bg-slate-800/60 border-slate-700/50 text-white placeholder:text-slate-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/30 transition-all duration-300 rounded-xl text-sm hover:bg-slate-800/80 focus:bg-slate-800/80"
                  />
                </div>
              </div>
            </div>

            {/* Password field */}
            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-slate-200 font-medium text-xs">
                Senha
              </Label>
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl opacity-0 group-hover:opacity-30 group-focus-within:opacity-40 blur-lg transition-all duration-500" />
                <div className="relative flex items-center">
                  <Lock className="absolute left-3 h-4 w-4 text-slate-500 group-hover:text-purple-400 group-focus-within:text-purple-400 transition-all duration-300" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Digite sua senha"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    required
                    className="pl-10 pr-10 h-11 bg-slate-800/60 border-slate-700/50 text-white placeholder:text-slate-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/30 transition-all duration-300 rounded-xl text-sm hover:bg-slate-800/80 focus:bg-slate-800/80"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 text-slate-500 hover:text-purple-400 transition-all duration-300 hover:scale-110"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Forgot password link */}
            <div className="flex justify-end">
              <Link 
                href="/forgot-password" 
                className="text-xs text-purple-400 hover:text-purple-300 font-medium transition-all duration-300 hover:translate-x-1 inline-block"
              >
                Esqueceu sua senha?
              </Link>
            </div>

            {/* Submit button */}
            <Button 
              type="submit" 
              className="w-full h-11 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 hover:from-purple-700 hover:via-blue-700 hover:to-pink-700 text-white font-semibold text-sm shadow-2xl shadow-purple-500/50 hover:shadow-purple-500/80 transition-all duration-500 transform hover:scale-[1.02] hover:-translate-y-0.5 relative overflow-hidden group rounded-xl"
              disabled={isLoading}
            >
              {/* Button shimmer effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" />
              
              {/* Button glow effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 opacity-0 group-hover:opacity-50 blur-xl transition-opacity duration-500" />
              
              <span className="relative flex items-center justify-center gap-2">
                {isLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Entrando...
                  </>
                ) : (
                  <>
                    Entrar no Sistema
                    <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform duration-300" />
                  </>
                )}
              </span>
            </Button>
          </form>

          {/* Footer compacto */}
          <div className="mt-6 text-center">
            <p className="text-slate-400 text-[10px] sm:text-xs font-medium">
              © 2025 Lopes Designer. Todos os direitos reservados.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
