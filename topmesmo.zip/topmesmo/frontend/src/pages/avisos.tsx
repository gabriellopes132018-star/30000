import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Plus, Bell, Loader2, AlertCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Announcement, User } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/contexts/AuthContext";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function Avisos() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    titulo: "",
    mensagem: "",
    targetRole: "",
  });

  const { data: announcements, isLoading } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
  });

  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/announcements", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/announcements"] });
      toast({ title: "Aviso publicado com sucesso!" });
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao publicar aviso",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      titulo: "",
      mensagem: "",
      targetRole: "",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const dataToSend = {
      ...formData,
      targetRole: formData.targetRole || null,
    };
    createMutation.mutate(dataToSend);
  };

  const getUserName = (id: string) => users?.find((u) => u.id === id)?.nome || "Administrador";

  const canCreateAnnouncements = user?.role === "admin";

  const filteredAnnouncements = announcements?.filter((announcement) => {
    if (!announcement.targetRole) return true;
    return announcement.targetRole === user?.role;
  });

  const getRoleLabel = (role: string | null) => {
    if (!role) return "Todos";
    const labels: Record<string, string> = {
      admin: "Administradores",
      gerente: "Gerentes",
      funcionario: "Funcionários",
    };
    return labels[role] || role;
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-4 sm:space-y-6 bg-gradient-to-br from-slate-50 via-purple-50/30 to-blue-50/30 dark:from-slate-950 dark:via-purple-950/20 dark:to-blue-950/20 min-h-screen">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 dark:from-purple-400 dark:via-pink-400 dark:to-blue-400 bg-clip-text text-transparent">
            Avisos
          </h1>
          <p className="text-slate-600 dark:text-slate-400 text-sm sm:text-base">Comunicados e notificações da equipe</p>
        </div>
        {canCreateAnnouncements && (
          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button 
                data-testid="button-novo-aviso"
                className="bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 hover:from-purple-700 hover:via-pink-700 hover:to-blue-700 text-white font-semibold shadow-xl shadow-purple-500/30 hover:shadow-purple-500/50 transition-all duration-300 transform hover:scale-105 relative overflow-hidden group"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" />
                <Plus className="mr-2 h-4 w-4 relative z-10" />
                <span className="relative z-10">Novo Aviso</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Novo Aviso</DialogTitle>
                <DialogDescription>
                  Publique um aviso para a equipe
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="titulo">Título *</Label>
                  <Input
                    id="titulo"
                    value={formData.titulo}
                    onChange={(e) => setFormData({ ...formData, titulo: e.target.value })}
                    required
                    data-testid="input-titulo"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mensagem">Mensagem *</Label>
                  <Textarea
                    id="mensagem"
                    value={formData.mensagem}
                    onChange={(e) => setFormData({ ...formData, mensagem: e.target.value })}
                    rows={4}
                    required
                    data-testid="input-mensagem"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="targetRole">Destinatários</Label>
                  <Select value={formData.targetRole || "all"} onValueChange={(value) => setFormData({ ...formData, targetRole: value === "all" ? "" : value })}>
                    <SelectTrigger data-testid="select-destinatarios">
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="admin">Administradores</SelectItem>
                      <SelectItem value="gerente">Gerentes</SelectItem>
                      <SelectItem value="funcionario">Funcionários</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={createMutation.isPending} data-testid="button-publicar">
                    {createMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Publicando...
                      </>
                    ) : (
                      "Publicar"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-64" />
                <Skeleton className="h-4 w-32 mt-2" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredAnnouncements && filteredAnnouncements.length > 0 ? (
        <div className="space-y-4">
          {filteredAnnouncements
            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
            .map((announcement) => (
              <Alert key={announcement.id} data-testid={`aviso-${announcement.id}`}>
                <AlertCircle className="h-5 w-5" />
                <AlertTitle className="flex items-center justify-between gap-4">
                  <span className="text-lg font-semibold">{announcement.titulo}</span>
                  <Badge variant="outline">
                    {getRoleLabel(announcement.targetRole)}
                  </Badge>
                </AlertTitle>
                <AlertDescription className="mt-3">
                  <p className="text-sm mb-3">{announcement.mensagem}</p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground pt-3 border-t">
                    <span>Por: {getUserName(announcement.createdById)}</span>
                    <span>{new Date(announcement.createdAt).toLocaleString("pt-BR")}</span>
                  </div>
                </AlertDescription>
              </Alert>
            ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Bell className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Nenhum aviso publicado</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
