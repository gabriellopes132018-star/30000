import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { NotificationsPanel } from "@/components/notifications-panel";
import { 
  LayoutDashboard, Users, FolderKanban, CheckSquare, 
  DollarSign, Clock, MessageSquare, Bell, 
  LogOut, ChevronLeft, ChevronRight, Sparkles,
  User, Search, Menu, X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const navigationItems = [
  { 
    title: "Dashboard", 
    path: "/dashboard", 
    icon: LayoutDashboard,
    color: "text-blue-600 dark:text-blue-400",
    gradient: "from-blue-500 to-cyan-500",
    roles: ["admin", "gerente", "funcionario"]
  },
  { 
    title: "Clientes", 
    path: "/clientes", 
    icon: Users,
    color: "text-purple-600 dark:text-purple-400",
    gradient: "from-purple-500 to-pink-500",
    roles: ["admin", "gerente", "funcionario"]
  },
  { 
    title: "Projetos", 
    path: "/projetos", 
    icon: FolderKanban,
    color: "text-pink-600 dark:text-pink-400",
    gradient: "from-pink-500 to-rose-500",
    roles: ["admin", "gerente", "funcionario"]
  },
  { 
    title: "Tarefas", 
    path: "/tarefas", 
    icon: CheckSquare,
    color: "text-emerald-600 dark:text-emerald-400",
    gradient: "from-emerald-500 to-teal-500",
    roles: ["admin", "gerente", "funcionario"]
  },
  { 
    title: "Financeiro", 
    path: "/financeiro", 
    icon: DollarSign,
    color: "text-green-600 dark:text-green-400",
    gradient: "from-green-500 to-emerald-500",
    roles: ["admin", "gerente"]
  },
  { 
    title: "Timesheet", 
    path: "/timesheet", 
    icon: Clock,
    color: "text-orange-600 dark:text-orange-400",
    gradient: "from-orange-500 to-amber-500",
    roles: ["admin", "gerente"]
  },
  { 
    title: "Gestão de Usuários", 
    path: "/usuarios", 
    icon: User,
    color: "text-indigo-600 dark:text-indigo-400",
    gradient: "from-indigo-500 to-purple-500",
    roles: ["admin", "gerente"]
  },
  { 
    title: "Chat", 
    path: "/chat", 
    icon: MessageSquare,
    color: "text-cyan-600 dark:text-cyan-400",
    gradient: "from-cyan-500 to-blue-500",
    roles: ["admin", "gerente", "funcionario"]
  },
  { 
    title: "Avisos", 
    path: "/avisos", 
    icon: Bell,
    color: "text-red-600 dark:text-red-400",
    gradient: "from-red-500 to-pink-500",
    roles: ["admin", "gerente", "funcionario"]
  },
];

export function MainLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    window.location.href = "/login";
  };

  return (
    <div className="flex h-screen w-full bg-gradient-to-br from-slate-50 via-slate-100 to-slate-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 overflow-hidden">
      {/* Mobile menu overlay */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar Ultra-Premium - Responsivo */}
      <aside 
        className={cn(
          "relative flex flex-col border-r border-slate-200/80 dark:border-slate-800/80 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl transition-all duration-500 ease-in-out shadow-2xl z-50",
          collapsed ? "w-20" : "w-80",
          // Mobile: sidebar escondida por padrão, aparece com overlay
          "fixed lg:relative inset-y-0 left-0",
          mobileMenuOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Gradient overlay sutil */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 via-purple-50/20 to-pink-50/30 dark:from-blue-950/20 dark:via-purple-950/10 dark:to-pink-950/20 pointer-events-none" />

        {/* Logo e Brand */}
        <div className="flex items-center justify-between h-20 px-5 border-b border-slate-200/80 dark:border-slate-800/80 relative z-10">
          <div className={cn(
            "flex items-center gap-3 transition-all duration-500",
            collapsed && "opacity-0 scale-90"
          )}>
            <div className="relative group">
              {/* Glow effect animado */}
              <div className="absolute -inset-2 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-xl blur-lg opacity-40 group-hover:opacity-70 animate-pulse transition-all duration-500" />
              <div className="relative flex items-center justify-center w-16 h-16 rounded-xl bg-black shadow-lg transform group-hover:scale-110 transition-all duration-500 overflow-hidden">
                <img 
                  src="/logo.png" 
                  alt="Lopes Designer" 
                  className="w-full h-full object-contain p-1"
                />
              </div>
            </div>
            <div className="transition-all duration-300">
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                Sistema de Gestão
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all duration-300 rounded-xl hover:scale-110"
            onClick={() => setCollapsed(!collapsed)}
          >
            {collapsed ? (
              <ChevronRight className="h-4 w-4 transition-transform duration-300" />
            ) : (
              <ChevronLeft className="h-4 w-4 transition-transform duration-300" />
            )}
          </Button>
        </div>

        {/* User Profile Premium */}
        <div className={cn(
          "p-5 border-b border-slate-200/80 dark:border-slate-800/80 relative z-10",
          collapsed && "px-3"
        )}>
          <div className={cn(
            "flex items-center gap-3 p-4 rounded-2xl bg-gradient-to-br from-slate-50 via-white to-slate-50 dark:from-slate-800 dark:via-slate-850 dark:to-slate-900 border border-slate-200/50 dark:border-slate-700/50 shadow-lg hover:shadow-xl transition-all duration-500 group relative overflow-hidden",
            collapsed && "justify-center p-3"
          )}>
            {/* Hover glow effect */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/0 via-purple-500/0 to-pink-500/0 group-hover:from-blue-500/5 group-hover:via-purple-500/5 group-hover:to-pink-500/5 transition-all duration-500" />
            
            <Avatar className="h-12 w-12 ring-2 ring-blue-500/50 ring-offset-2 dark:ring-offset-slate-900 shadow-lg group-hover:ring-purple-500/70 transition-all duration-500 relative z-10">
              <AvatarFallback className="bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white font-bold text-lg">
                {user?.nome?.charAt(0) || "U"}
              </AvatarFallback>
            </Avatar>
            {!collapsed && (
              <div className="flex-1 min-w-0 relative z-10">
                <p className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                  {user?.nome || "Usuário"}
                </p>
                <p className="text-xs text-slate-600 dark:text-slate-400 capitalize truncate font-medium">
                  {user?.role === "admin" ? "Administrador" : 
                   user?.role === "gerente" ? "Gerente" : "Funcionário"}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Navigation Ultra-Premium */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto relative z-10">
          {navigationItems.filter(item => item.roles.includes(user?.role || "funcionario")).map((item, index) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <Link 
                key={item.path} 
                href={item.path}
                onClick={() => setMobileMenuOpen(false)}
                className={cn(
                  "flex items-center gap-4 px-4 py-3.5 rounded-2xl font-semibold transition-all duration-300 group relative overflow-hidden touch-manipulation",
                  isActive 
                    ? "bg-gradient-to-r from-blue-50 via-purple-50 to-pink-50 dark:from-blue-950/50 dark:via-purple-950/50 dark:to-pink-950/50 text-blue-600 dark:text-blue-400 shadow-lg shadow-blue-500/10 dark:shadow-blue-500/5"
                    : "text-slate-600 dark:text-slate-400 hover:bg-slate-100/70 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-slate-100 hover:shadow-md active:scale-95",
                  collapsed && "justify-center px-0"
                )}
                style={{
                  animationDelay: `${index * 50}ms`
                }}
              >
                {/* Active indicator bar com gradiente */}
                {isActive && (
                  <div className="absolute left-0 top-1 bottom-1 w-1.5 rounded-r-full bg-gradient-to-b from-blue-600 to-purple-600 shadow-lg" />
                )}

                {/* Icon com animação */}
                <Icon className={cn(
                  "h-5 w-5 flex-shrink-0 transition-all duration-300 relative z-10",
                  "group-hover:scale-125 group-hover:rotate-6",
                  isActive && item.color,
                  isActive && "drop-shadow-lg"
                )} />
                
                {!collapsed && (
                  <span className="text-sm relative z-10 transition-all duration-300 group-hover:translate-x-1">
                    {item.title}
                  </span>
                )}

              </Link>
            );
          })}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-slate-200/80 dark:border-slate-800/80 space-y-2 relative z-10">
          <Button
            variant="ghost"
            className={cn(
              "w-full justify-start text-slate-600 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 transition-all duration-300 rounded-xl h-12 font-semibold group",
              collapsed && "justify-center px-0"
            )}
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5 flex-shrink-0 transition-transform duration-300 group-hover:scale-110 group-hover:-translate-x-0.5" />
            {!collapsed && <span className="ml-3 transition-all duration-300 group-hover:translate-x-1">Sair</span>}
          </Button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Gradient overlay no fundo */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 via-transparent to-purple-50/30 dark:from-blue-950/10 dark:via-transparent dark:to-purple-950/10 pointer-events-none" />

        {/* Top Navigation Bar Premium - Mobile Optimized */}
        <header className="flex items-center justify-between h-16 sm:h-20 px-3 sm:px-6 md:px-8 bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl border-b border-slate-200/80 dark:border-slate-800/80 shadow-lg relative z-10">
          {/* Botão Menu Hamburguer Mobile */}
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden h-10 w-10 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all duration-300 active:scale-95"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="h-5 w-5" />
            ) : (
              <Menu className="h-5 w-5" />
            )}
          </Button>

          <div className="flex items-center gap-2 sm:gap-6 flex-1">
            <div className="relative flex-1 max-w-xl group hidden sm:block">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-hover:text-purple-500 transition-colors duration-300" />
              <input
                type="text"
                placeholder="Buscar em todo o sistema..."
                className="w-full pl-12 pr-4 py-3 text-sm bg-slate-50/80 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50 transition-all duration-300 hover:bg-white dark:hover:bg-slate-800 shadow-sm hover:shadow-md"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-2 sm:gap-3">
            <NotificationsPanel />
            <div className="transition-all duration-300 hover:scale-110 active:scale-95">
              <ThemeToggle />
            </div>
          </div>
        </header>

        {/* Page Content com animação de entrada - Mobile Optimized */}
        <main className="flex-1 overflow-auto relative z-10 overscroll-contain">
          <div className="min-h-full">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
