import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { ProtectedRoute } from "@/components/protected-route";
import { MainLayout } from "@/components/main-layout";
import Login from "@/pages/login";
import ForgotPassword from "@/pages/forgot-password";
import ResetPassword from "@/pages/reset-password";
import Dashboard from "@/pages/dashboard";
import Clientes from "@/pages/clientes";
import Projetos from "@/pages/projetos";
import Tarefas from "@/pages/tarefas";
import Financeiro from "@/pages/financeiro";
import Timesheet from "@/pages/timesheet";
import Usuarios from "@/pages/usuarios";
import Chat from "@/pages/chat";
import Avisos from "@/pages/avisos";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Login} />
      <Route path="/login" component={Login} />
      <Route path="/forgot-password" component={ForgotPassword} />
      <Route path="/reset-password" component={ResetPassword} />
      <Route path="/dashboard">
        <ProtectedRoute>
          <MainLayout>
            <Dashboard />
          </MainLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/clientes">
        <ProtectedRoute>
          <MainLayout>
            <Clientes />
          </MainLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/projetos">
        <ProtectedRoute>
          <MainLayout>
            <Projetos />
          </MainLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/tarefas">
        <ProtectedRoute>
          <MainLayout>
            <Tarefas />
          </MainLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/financeiro">
        <ProtectedRoute>
          <MainLayout>
            <Financeiro />
          </MainLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/timesheet">
        <ProtectedRoute>
          <MainLayout>
            <Timesheet />
          </MainLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/usuarios">
        <ProtectedRoute>
          <MainLayout>
            <Usuarios />
          </MainLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/chat">
        <ProtectedRoute>
          <MainLayout>
            <Chat />
          </MainLayout>
        </ProtectedRoute>
      </Route>
      <Route path="/avisos">
        <ProtectedRoute>
          <MainLayout>
            <Avisos />
          </MainLayout>
        </ProtectedRoute>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
